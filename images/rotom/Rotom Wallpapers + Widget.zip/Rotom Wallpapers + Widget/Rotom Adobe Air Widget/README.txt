The Pokémon Platinum Desktop widget requires the Adobe Air runtime to be installed first.

Visit http://get.adobe.com/air/ to download and install Adobe Air.

Visit http://www.adobe.com/products/air/ to learn more about Adobe Air.